extends Area2D

func _on_body_entered(body):
	if body.name == "Player":
		get_tree().get_first_node_in_group("hud").add_coin()
		queue_free()
