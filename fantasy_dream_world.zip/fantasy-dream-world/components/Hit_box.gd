extends AnimatableBody2D

@export var speed = 100
@export var distance = 200

var start_pos
var direction = 1

func _ready():
	start_pos = global_position

func _physics_process(delta):
	position.x += speed * direction * delta

	if position.x > start_pos.x + distance:
		direction = -1

	if position.x < start_pos.x - distance:
		direction = 1
